DROP TABLE IF EXISTS article_categories;
DROP TABLE IF EXISTS categories;